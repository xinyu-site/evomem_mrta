![alt text](image.png)
* `run_no_memory.py`: use="false"，useab="false"，record="false"
* `run_no_record_80.py`：record="false"，num_problems=10
* `run_no_evolve.py`：evolve="false"
* `run_no_forget.py`：forget="false"
* `run_no_check.py`: check="false"
